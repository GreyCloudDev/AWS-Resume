namespace tests
{
    public enum LoggerTypes
    {
        Null,
        List
    }
}